#!/bin/bash
# start.sh - THE entry point for a CyberPatriot Linux round. From inside competition/:
#
#     sudo bash start.sh            menu (resumable: quit any time, run it again to continue)
#     sudo bash start.sh --status   print the menu/status once and exit (changes nothing)
#     sudo bash start.sh --reset    forget step ticks and background-job state (README answers are kept;
#                                   readme.sh --reset forgets those)
#
# What it does
#   1. Starts the slow work in the background at once (logs in /root/cp-state/logs/bg-*.log):
#        apt   : apt-get update, then DOWNLOADS every upgrade into /var/cache/apt/cp-upgrades/ - nothing is
#                installed until you say yes in the Upgrades step. A separate download folder means the
#                download never holds the apt archive lock the scripts' own apt-get calls need.
#        baseline: services/baseline.sh (detection only, needs no terminal).
#   2. README intake (readme.sh) if the README answers are not saved yet.
#   3. Menu, steps in the right order, each ticked with its duration once done:
#        Enter = next step that is not done, a number = that step, a = auto mode on/off (CP_AUTO=1 by
#        default: always-right steps are not asked), t = combined TODO list, q = quit.
#      Steps that change the system wait for the background baseline scan (it must see the untouched
#      image); steps that use apt wait for the background apt-get update (the lists lock would make
#      their own "apt-get update" fail). Both waits: any key = back to the menu, s = run anyway.
#   4. Every step's full output goes to /root/cp-state/logs/<step>.log (via `script`, so the step stays
#      interactive and coloured). Before each script step the scoring report is snapshotted
#      (cp_screenshot_prompt) - or, without a report, ONE screenshot reminder per step.
#
# State: /root/cp-state/start/ (step ticks, background jobs, auto mode), README answers in
# /root/cp-state/readme.conf, TODO list in /root/cp-state/TODO.txt. Every other script still works on
# its own (sudo bash usersandsudo.sh ...). Steps whose script is missing are skipped with a warning.

SELF="$(readlink -f "${BASH_SOURCE[0]}")"
HERE="$(dirname "$SELF")"
# shellcheck disable=SC2034  # used by cp-common.sh (cp_todo tag)
CP_SCRIPT_NAME=start.sh
# shellcheck source=cp-common.sh
source "$HERE/cp-common.sh" 2>/dev/null || { echo "ERROR: cp-common.sh not found next to start.sh"; exit 1; }
cp_require_root
cd "$HERE" || exit 1

ST="$CP_STATE_DIR/start"
JOBS="$ST/jobs"
LOGS="$CP_STATE_DIR/logs"
UPG_DIR=/var/cache/apt/cp-upgrades
CHECKLIST="$HERE/CP Linux Checklist.txt"
mkdir -p "$JOBS" "$LOGS" && chmod 700 "$CP_STATE_DIR" "$ST" "$LOGS"

# ------------------------------------------------------------------ steps --
STEPS=(readme forensics review users system packages ports critical upgrades manual todo)
declare -A SNAME SCMD
SNAME[readme]="README intake";                 SCMD[readme]="readme.sh"
SNAME[forensics]="Forensics + EARLY MANUAL list"
SNAME[review]="Baseline review";               SCMD[review]="services/baseline.sh --review"
SNAME[users]="Users + sudo";                   SCMD[users]="usersandsudo.sh"
SNAME[system]="System config";                 SCMD[system]="systemconfig.sh"
SNAME[packages]="Packages + files";            SCMD[packages]="fileandpackage.sh"
SNAME[ports]="Ports";                          SCMD[ports]="portandmisc.sh"
SNAME[critical]="Critical services";           SCMD[critical]="services/critical.sh"
SNAME[upgrades]="Upgrades (install downloaded)"
SNAME[manual]="LATE MANUAL list"
SNAME[todo]="Final TODO list"
SNAME[baseline-scan]="Baseline scan (foreground)"
CHANGE_STEPS=" users system packages ports critical upgrades "   # wait for the baseline scan
APT_STEPS=" review system packages ports critical upgrades "     # wait for the background apt-get update
SHOT_STEPS=" review users system packages ports critical "

# README intake only counts as done while the answers are saved (a failed/aborted intake must come back)
readme_ok() { [ -n "$(cp_cfg_get ADMINS)" ]; }
step_done() { [ -f "$ST/step.$1" ] && { [ "$1" != readme ] || readme_ok; }; }
step_set()  { echo "$2 $3 $(date +%s)" > "$ST/step.$1"; }        # rc|m|bg  duration  epoch
step_rc()   { awk '{print $1}' "$ST/step.$1" 2>/dev/null; }
step_dur()  { awk '{print $2}' "$ST/step.$1" 2>/dev/null; }

fmt_dur() {
    local s="${1:-0}"
    if [ "$s" -ge 3600 ]; then printf '%dh%02dm' $((s / 3600)) $((s % 3600 / 60))
    elif [ "$s" -ge 60 ]; then printf '%dm%02ds' $((s / 60)) $((s % 60))
    else printf '%ds' "$s"; fi
}
auto_on() { [ "$(cat "$ST/auto" 2>/dev/null || echo 1)" = 1 ]; }
todo_count() { if [ -f "$CP_TODO_FILE" ]; then grep -c . "$CP_TODO_FILE"; else echo 0; fi; }

# ---------------------------------------------------------- background jobs --
# Each job runs as `bash start.sh --job NAME` in its own session (survives quitting start.sh) and
# leaves NAME.{start,pid,phase,rc,end} in $JOBS.
job_state() {   # none | running | done | failed | died
    local n="$1" pid
    [ -f "$JOBS/$n.start" ] || { echo none; return; }
    if [ -f "$JOBS/$n.end" ]; then
        if [ "$(cat "$JOBS/$n.rc" 2>/dev/null)" = 0 ]; then echo "done"; else echo failed; fi
        return
    fi
    pid="$(cat "$JOBS/$n.pid" 2>/dev/null)"
    if [ -n "$pid" ] && grep -qa -- "--job" "/proc/$pid/cmdline" 2>/dev/null; then echo running; else echo died; fi
}
job_secs() {
    local n="$1" s e
    s="$(cat "$JOBS/$n.start" 2>/dev/null)"; [ -n "$s" ] || { echo 0; return; }
    e="$(cat "$JOBS/$n.end" 2>/dev/null)"; [ -n "$e" ] || e="$(date +%s)"
    echo $(( e - s ))
}
job_spawn() {
    local n="$1"
    rm -f "$JOBS/$n".{end,rc,phase,pid,update_rc,note}
    date +%s > "$JOBS/$n.start"
    ( umask 077; : > "$LOGS/bg-$n.log" )
    if command -v setsid >/dev/null 2>&1; then
        setsid bash "$SELF" --job "$n" > "$LOGS/bg-$n.log" 2>&1 < /dev/null 9>&- &
    else
        nohup bash "$SELF" --job "$n" > "$LOGS/bg-$n.log" 2>&1 < /dev/null 9>&- &
    fi
    disown 2>/dev/null
    local i; for i in 1 2 3 4 5 6 7 8 9 10; do [ -s "$JOBS/$n.pid" ] && break; sleep 0.1; done
}
job_stop() {   # stop a running job (its whole session), record it as stopped
    local n="$1" pid
    pid="$(cat "$JOBS/$n.pid" 2>/dev/null)"
    [ -n "$pid" ] && { kill -TERM -- "-$pid" 2>/dev/null || kill -TERM "$pid" 2>/dev/null; }
    sleep 1
    echo 143 > "$JOBS/$n.rc"; echo "$2" > "$JOBS/$n.note"; date +%s > "$JOBS/$n.end"
}

job_apt() {
    local i rc=1 rc2 tmp="$JOBS/apt.out"
    echo update > "$JOBS/apt.phase"
    for i in $(seq 1 60); do      # apt-daily / mintupdate may hold the lists lock right after boot
        LC_ALL=C timeout 600 /usr/bin/apt-get -q update > "$tmp" 2>&1; rc=$?
        cat "$tmp"
        if [ "$rc" -ne 0 ] && grep -q 'Could not get lock' "$tmp"; then
            echo "[start.sh] apt lists are locked by another apt process - retrying in 5 s"; sleep 5; continue
        fi
        break
    done
    rm -f "$tmp"
    echo "$rc" > "$JOBS/apt.update_rc"
    [ "$rc" -eq 0 ] && date +%s > "$CP_STATE_DIR/apt-updated"   # scripts may skip their own apt-get update
    echo download > "$JOBS/apt.phase"
    mkdir -p "$UPG_DIR/partial"
    echo "[start.sh] downloading upgrades into $UPG_DIR (download only - nothing is installed)"
    LC_ALL=C /usr/bin/apt-get -q -d -y -o Dir::Cache::archives="$UPG_DIR/" full-upgrade; rc2=$?
    echo "[start.sh] $(ls "$UPG_DIR"/*.deb 2>/dev/null | wc -l) package files downloaded"
    [ "$rc" -eq 0 ] && return "$rc2"
    return "$rc"
}
job_baseline() {
    [ -f "$HERE/services/baseline.sh" ] || { echo "services/baseline.sh not found"; return 127; }
    CP_AUTO=1 bash "$HERE/services/baseline.sh"
}
job_upgrade() {
    local rc
    # keep every config file the scripts hardened (dpkg conffiles AND ucf-managed ones like sshd_config)
    DEBIAN_FRONTEND=noninteractive APT_LISTCHANGES_FRONTEND=none NEEDRESTART_SUSPEND=1 NEEDRESTART_MODE=l \
    UCF_FORCE_CONFFOLD=1 LC_ALL=C /usr/bin/apt-get -q -y -o DPkg::Lock::Timeout=600 -o Dir::Cache::archives="$UPG_DIR/" \
        -o Dpkg::Options::=--force-confdef -o Dpkg::Options::=--force-confold full-upgrade
    rc=$?
    [ "$rc" -eq 0 ] && /usr/bin/apt-get -q -o Dir::Cache::archives="$UPG_DIR/" clean
    return "$rc"
}

if [ "${1:-}" = "--job" ]; then
    n="${2:-}"; echo $$ > "$JOBS/$n.pid"
    case "$n" in
        apt) job_apt ;; baseline) job_baseline ;; upgrade) job_upgrade ;;
        *) echo "unknown job $n"; false ;;
    esac
    rc=$?
    echo "$rc" > "$JOBS/$n.rc"; date +%s > "$JOBS/$n.end"
    exit "$rc"
fi

findings_count() {   # "FIX NOW n, REVIEW n" from FINDINGS.txt (baseline.sh), else the number of "!!" report lines
    local h; h="$(grep -m1 -oE 'FIX NOW: *[0-9]+ +REVIEW: *[0-9]+' "$CP_BASELINE_DIR/FINDINGS.txt" 2>/dev/null)"
    if [ -n "$h" ]; then echo "$h" | sed -E 's/FIX NOW: *([0-9]+) +REVIEW: *([0-9]+)/FIX NOW \1, REVIEW \2/'
    else echo "$(cat "$CP_BASELINE_DIR"/*/report.txt 2>/dev/null | grep -cE '^[[:space:]]*!!') !!"; fi
}
debs_count() { ls "$UPG_DIR"/*.deb 2>/dev/null | wc -l; }

job_text() {   # one short status phrase per job
    local n="$1" s; s="$(job_state "$n")"
    local t; t="$(fmt_dur "$(job_secs "$n")")"
    case "$n:$s" in
        apt:none)      echo "apt: not started" ;;
        apt:running)   if [ "$(cat "$JOBS/apt.phase" 2>/dev/null)" = download ]; then
                           echo "apt: update ${CP_C_GRN}ok${CP_C_OFF}, downloading upgrades $t ($(debs_count) files)"
                       else echo "apt: ${CP_C_YEL}apt-get update running${CP_C_OFF} $t"; fi ;;
        apt:done)      if [ "$(job_state upgrade)" = none ]; then echo "apt: ${CP_C_GRN}done${CP_C_OFF} $t, $(debs_count) upgrade files ready"
                       else echo "apt: ${CP_C_GRN}done${CP_C_OFF} $t"; fi ;;
        apt:failed)    if [ -s "$JOBS/apt.note" ]; then echo "apt: $(cat "$JOBS/apt.note")"
                       elif [ "$(cat "$JOBS/apt.update_rc" 2>/dev/null)" != 0 ]; then
                           echo "apt: ${CP_C_RED}apt-get update FAILED${CP_C_OFF} (log: $LOGS/bg-apt.log)"
                       else echo "apt: ${CP_C_RED}upgrade download failed${CP_C_OFF} (log: $LOGS/bg-apt.log)"; fi ;;
        baseline:none) echo "baseline scan: not started" ;;
        baseline:running) echo "baseline scan: ${CP_C_YEL}running${CP_C_OFF} $t" ;;
        baseline:done) if [ -s "$JOBS/baseline.note" ]; then echo "baseline scan: ${CP_C_GRN}done${CP_C_OFF} ($(cat "$JOBS/baseline.note"))"
                       else echo "baseline scan: ${CP_C_GRN}done${CP_C_OFF} $t, $(findings_count) (list: $CP_BASELINE_DIR/FINDINGS.txt)"; fi ;;
        baseline:failed) if [ "$(cat "$JOBS/baseline.rc" 2>/dev/null)" = 127 ]; then echo "baseline scan: ${CP_C_RED}services/baseline.sh missing${CP_C_OFF}"
                       else echo "baseline scan: ${CP_C_RED}failed${CP_C_OFF} (log: $LOGS/bg-baseline.log)"; fi ;;
        upgrade:running) echo "upgrades: ${CP_C_YEL}installing${CP_C_OFF} $t" ;;
        upgrade:done)  echo "upgrades: ${CP_C_GRN}installed${CP_C_OFF} $t" ;;
        upgrade:failed) echo "upgrades: ${CP_C_RED}install failed${CP_C_OFF} (log: $LOGS/bg-upgrade.log)" ;;
        *:died)        echo "$n: ${CP_C_RED}job died${CP_C_OFF} (j restarts it)" ;;
        *)             echo "" ;;
    esac
}

start_jobs() {   # start what has not run yet (or died, e.g. after a reboot)
    local s
    s="$(job_state apt)"
    if [ "$s" = none ] || [ "$s" = died ]; then job_spawn apt; fi
    s="$(job_state baseline)"
    if [ "$s" = none ] && ls "$CP_BASELINE_DIR"/*/report.txt >/dev/null 2>&1; then
        # baseline.sh already ran before start.sh (by hand) - a re-run now would compare a changed image
        date +%s > "$JOBS/baseline.start"; cp "$JOBS/baseline.start" "$JOBS/baseline.end"
        echo 0 > "$JOBS/baseline.rc"; echo "earlier run, $(findings_count)" > "$JOBS/baseline.note"
    elif [ "$s" = none ] || [ "$s" = died ]; then
        job_spawn baseline
    fi
}

# wait_job NAME TEXT [phase] -> 0 = go on, 1 = back to the menu. Any key = back, s = go on anyway.
wait_job() {
    local n="$1" what="$2" phase="${3:-}" k
    busy() { [ "$(job_state "$n")" = running ] && { [ -z "$phase" ] || [ "$(cat "$JOBS/$n.phase" 2>/dev/null)" = "$phase" ]; }; }
    busy || return 0
    cp_warn "$what"
    if [ ! -t 0 ]; then while busy; do sleep 2; done; return 0; fi
    echo "    Waiting - any key = back to the menu, s = run this step anyway."
    while busy; do
        printf '\r    %s: %s running ...   ' "$n" "$(fmt_dur "$(job_secs "$n")")"
        if read -rsn1 -t 1 k; then
            echo
            [ "$k" = s ] || [ "$k" = S ] && return 0
            return 1
        fi
    done
    printf '\r    %s finished after %s.                 \n' "$n" "$(fmt_dur "$(job_secs "$n")")"
    return 0
}

# ---------------------------------------------------------- running steps --
clean_log() {   # strip colours/cursor codes so the log reads well with less/grep
    [ -f "$1" ] || return 0
    sed -i -E -e 's/\x1b\[[0-9;?]*[ -\/]*[@-~]//g' -e 's/\x1b\][^\x07]*\x07//g' -e 's/\x1b[()][A-Z0-9]//g' \
        -e 's/\x1b[=>]//g' -e 's/^.*\r([^\r])/\1/' -e 's/\r$//' "$1" 2>/dev/null
}

INTERRUPTED=0
run_script() {   # run_script ID FILE [ARGS...]
    local id="$1" f="$2"; shift
    local log="$LOGS/$id.log" t0 rc todo0 new
    if [ ! -f "$HERE/$f" ]; then
        cp_warn "$f is not in this folder - step skipped (copy the whole competition folder)"; return 1
    fi
    if [[ "$SHOT_STEPS" == *" $id "* ]]; then
        cp_screenshot_prompt "$id"
        echo "$id" > "$ST/shot-pending"   # the script's own cp_screenshot_prompt call is then skipped
    fi
    todo0="$(todo_count)"
    ( umask 077; : > "$log" )
    t0="$(date +%s)"
    INTERRUPTED=0; trap 'INTERRUPTED=1' INT
    if [ "$id" = readme ]; then
        # NO transcript: the README paste contains the admin passwords, and readme.sh keeps them in memory
        # only. `script` or tee would write them to the log - so this step runs unlogged.
        echo "README intake output is not logged (the paste contains passwords). Saved answers: sudo bash readme.sh --show" > "$log"
        cp_hdr "Step: ${SNAME[$id]}  ($*)   (not logged: the README paste contains passwords)"
        if [ -t 0 ]; then
            CP_AUTO="$(auto_on && echo 1 || echo 0)" CP_START_STEP="$id" CP_SHOT_ASKED="$id" CP_FROM_START=1 bash "$@"
        else
            CP_AUTO="$(auto_on && echo 1 || echo 0)" CP_START_STEP="$id" CP_SHOT_ASKED="$id" CP_FROM_START=1 bash "$@" < /dev/null
        fi
        rc=$?
    elif [ -t 0 ] && command -v script >/dev/null 2>&1; then
        cp_hdr "Step: ${SNAME[$id]}  ($*)   log: $log"
        CP_AUTO="$(auto_on && echo 1 || echo 0)" CP_START_STEP="$id" CP_SHOT_ASKED="$id" CP_FROM_START=1 \
            SHELL=/bin/bash script -qefc "$(printf '%q ' bash "$@")" "$log"
        rc=$?
    elif [ -t 0 ]; then
        cp_hdr "Step: ${SNAME[$id]}  ($*)   log: $log"
        CP_AUTO="$(auto_on && echo 1 || echo 0)" CP_START_STEP="$id" CP_SHOT_ASKED="$id" CP_FROM_START=1 \
            bash "$@" 2>&1 | tee "$log"
        rc="${PIPESTATUS[0]}"
    else   # no terminal: the scripts take their defaults
        cp_hdr "Step: ${SNAME[$id]}  ($*)   log: $log"
        CP_AUTO="$(auto_on && echo 1 || echo 0)" CP_START_STEP="$id" CP_SHOT_ASKED="$id" CP_FROM_START=1 \
            bash "$@" < /dev/null 2>&1 | tee "$log"
        rc="${PIPESTATUS[0]}"
    fi
    trap - INT
    rm -f "$ST/shot-pending"
    clean_log "$log"
    if [ "$INTERRUPTED" = 1 ] || [ "$rc" -eq 130 ] || [ "$rc" -gt 128 ]; then
        echo; cp_warn "${SNAME[$id]} was interrupted (exit $rc) - not ticked. Output so far: $log"
        return 1
    fi
    if [ "$id" = readme ] && ! readme_ok; then
        echo; cp_warn "README answers were not saved (exit $rc) - not ticked; Enter runs the README intake again."
        return 1
    fi
    step_set "$id" "$rc" $(( $(date +%s) - t0 ))
    new=$(( $(todo_count) - todo0 ))
    echo
    if [ "$rc" -eq 0 ]; then
        cp_ok "${SNAME[$id]} done in $(fmt_dur $(( $(date +%s) - t0 )))$([ "$new" -gt 0 ] && echo " - $new new TODO item(s), t lists them"). Full output: $log"
    else
        cp_warn "${SNAME[$id]} ended with exit $rc after $(fmt_dur $(( $(date +%s) - t0 ))) - ticked anyway, check the end of $log$([ "$new" -gt 0 ] && echo "; $new new TODO item(s)")"
    fi
    return 0
}

print_section() {   # print_section NAME -> the checklist section "==== NAME (...) ====" without the dividers
    [ -f "$CHECKLIST" ] || { cp_warn "Checklist not found: $CHECKLIST"; return 1; }
    awk -v name="$1" -v b="$CP_C_CYN" -v o="$CP_C_OFF" '
        /^=+/ { insec = (index($0, "= " name) > 0); next }
        insec && /^\* / { print b $0 o; next }
        insec { print }' "$CHECKLIST" | sed 's/[[:space:]]*$//'
}

step_manual_list() {   # step_manual_list ID SECTION QUESTION
    local id="$1" t0; t0="$(date +%s)"
    cp_hdr "${SNAME[$id]} - from CP Linux Checklist.txt (copy commands from the tracker or below)"
    print_section "$2"
    echo
    if cp_ask "$3" y; then step_set "$id" m $(( $(date +%s) - t0 )); cp_ok "Ticked."
    else cp_info "Not ticked - Enter in the menu brings this list back."; fi
}

step_forensics() {
    local f found=0
    cp_hdr "Forensics questions - answer them BEFORE removing users, files or packages"
    for f in /home/*/Desktop/*[Ff]orensic* /root/Desktop/*[Ff]orensic*; do
        [ -e "$f" ] || continue
        found=1; cp_info "$f"
    done
    [ "$found" = 1 ] || cp_info "(no Forensics Question files found on any Desktop - check the README)"
    step_manual_list forensics "EARLY MANUAL" "Forensics answered and EARLY MANUAL items done?"
}

step_todo() {
    local t0; t0="$(date +%s)"
    show_todo
    if cp_ask "All TODO items handled?" y; then step_set todo m $(( $(date +%s) - t0 )); fi
}

show_todo() {
    cp_hdr "TODO - things only you can finish ($CP_TODO_FILE)"
    if [ -s "$CP_TODO_FILE" ]; then
        awk '{ printf "  %2d. %s\n", NR, $0 }' "$CP_TODO_FILE"
    else
        cp_info "No TODO items yet."
    fi
}

step_review() {
    local s; s="$(job_state baseline)"
    if [ ! -f "$HERE/services/baseline.sh" ]; then cp_warn "services/baseline.sh is not in this folder - step skipped"; return 1; fi
    case "$s" in
        running) wait_job baseline "The background baseline scan is still running - the review needs its results." || return 1 ;;
        done) ;;
        *)  cp_warn "The background baseline scan did not finish ($s) - log: $LOGS/bg-baseline.log"
            cp_ask "Run the scan now (detection only, in the foreground)?" y || return 1
            run_script baseline-scan services/baseline.sh || return 1
            date +%s > "$JOBS/baseline.start"; cp "$JOBS/baseline.start" "$JOBS/baseline.end"; echo 0 > "$JOBS/baseline.rc"
            echo "foreground run, $(findings_count)" > "$JOBS/baseline.note"
            rm -f "$ST/step.baseline-scan" ;;
    esac
    run_script review services/baseline.sh --review
}

step_critical() {
    local s ran=0
    if [ -f "$HERE/services/critical.sh" ]; then run_script critical services/critical.sh; return; fi
    cp_warn "services/critical.sh not found - running services/<name>.sh for each README critical service"
    for s in $(cp_cfg_get SERVICES); do
        [ "$s" = none ] && continue
        if [ -f "$HERE/services/$s.sh" ]; then run_script "critical" "services/$s.sh"; ran=1
        else cp_warn "services/$s.sh not found"; fi
    done
    [ "$ran" = 1 ] || { cp_info "No critical services to harden."; step_set critical 0 0; }
}

step_readme() {
    if [ -f "$HERE/readme.sh" ]; then
        # first time: --if-missing (no "Keep these answers?" when they are already saved); re-run by number:
        # plain readme.sh, which shows the saved answers and lets you change them
        if step_done readme; then run_script readme readme.sh; else run_script readme readme.sh --if-missing; fi
        return
    fi
    local a u s
    cp_warn "readme.sh not found - minimal intake"
    a="$(cp_read "Authorized administrators (space-separated, yours too)" "$(cp_cfg_get ADMINS)")"
    u="$(cp_read "Authorized standard users (space-separated)" "$(cp_cfg_get USERS)")"
    s="$(cp_read "Critical services (ssh vsftpd apache2 nginx php mysql postgresql samba bind9 mail wordpress openvpn squid, or none)" "$(cp_cfg_get SERVICES)")"
    [ -n "$a" ] || { cp_warn "No administrators entered - not saved."; return 1; }
    cp_cfg_set ADMINS $a; cp_cfg_set USERS $u; cp_cfg_set SERVICES ${s:-none}
    [ -n "${SUDO_USER:-}" ] && cp_cfg_set ME "$SUDO_USER"
    step_set readme 0 0
}

step_upgrades() {
    local sim n_inst n_rem def=y repos r bad=0 notable
    cp_hdr "Upgrades - install what the background job downloaded"
    case "$(job_state apt):$(cat "$JOBS/apt.phase" 2>/dev/null)" in
        running:update) wait_job apt "apt-get update is still running." update || return 1 ;;
        running:download)
            cp_info "The upgrade download is still running ($(debs_count) files so far) - stopping it; the install fetches the rest."
            job_stop apt "download stopped for the install ($(debs_count) files ready)" ;;
    esac
    if [ "$(cat "$JOBS/apt.update_rc" 2>/dev/null)" != 0 ]; then
        cp_warn "The background apt-get update did not succeed (log: $LOGS/bg-apt.log) - running it now."
        cp_info "Linux Mint: if it keeps failing, Update Manager -> Edit -> Software Sources -> restore the default settings, then refresh."
        LC_ALL=C /usr/bin/apt-get -q update 2>&1 | tail -n 5
    fi
    cp_info "Repositories apt uses (anything that is not Ubuntu/Mint/Canonical: check /etc/apt/sources.list*):"
    repos="$(LC_ALL=C /usr/bin/apt-cache policy 2>/dev/null | grep -oE '(https?|ftp|file|cdrom):[^ ]+' | sort -u)"
    for r in $repos; do
        if [[ "$r" =~ (ubuntu|linuxmint|canonical) ]]; then echo "      $r"
        else echo "      ${CP_C_YEL}$r${CP_C_OFF}  <- check"; bad=1
             cp_todo "APT repository that is not Ubuntu/Mint: $r - check /etc/apt/sources.list(.d) (keep it only if the README needs it)"; fi
    done
    [ "$bad" = 1 ] && cp_warn "Upgrades from an unknown repository can install anything - check it before saying yes."
    sim="$(LC_ALL=C /usr/bin/apt-get -s -o Dir::Cache::archives="$UPG_DIR/" full-upgrade 2>&1)"
    n_inst="$(grep -c '^Inst ' <<<"$sim")"; n_rem="$(grep -c '^Remv ' <<<"$sim")"
    if [ "$n_inst" -eq 0 ] && [ "$n_rem" -eq 0 ]; then
        cp_ok "Nothing to upgrade."; step_set upgrades 0 0; return 0
    fi
    notable="$(grep '^Inst ' <<<"$sim" | awk '{print $2}' | grep -E '^(bash|sudo|linux-image|linux-generic|firefox|libreoffice-core|thunderbird|openssh-server|openssl|apache2|nginx|vsftpd|mysql-server|mariadb-server|postgresql|samba|bind9|postfix|dovecot-core|php[0-9.]*|openvpn|squid|cinnamon|policykit-1|pkexec)' | head -12 | tr '\n' ' ')"
    cp_info "$n_inst package(s) to upgrade/install ($(debs_count) already downloaded)${notable:+ - includes: $notable}"
    if [ "$n_rem" -gt 0 ]; then
        cp_warn "It would also REMOVE: $(grep '^Remv ' <<<"$sim" | awk '{print $2}' | tr '\n' ' ')"
        def=n
    fi
    if [[ "$(cp_os_id)" == linuxmint* ]]; then
        cp_info "Linux Mint: Update Manager automation is done by systemconfig.sh - this installs the upgrades now."
    fi
    if cp_ask "Install them now in the background (keeps your config files; log: $LOGS/bg-upgrade.log)?" "$def"; then
        job_spawn upgrade
        step_set upgrades bg 0
        cp_ok "Installing in the background - the menu shows its progress. Go on with the next step."
    else
        cp_info "Not installed - run this step again when you want them."
    fi
}

run_step() {
    local id="$1"
    if [[ "$CHANGE_STEPS" == *" $id "* ]]; then
        wait_job baseline "The baseline scan is still running - it should see the image before anything is changed." || return 1
    fi
    if [[ "$APT_STEPS" == *" $id "* ]] && [ "$id" != upgrades ]; then
        wait_job apt "The background apt-get update is still running (an apt-get update in this step would fail on its lock)." update || return 1
        if [ "$(job_state upgrade)" = running ]; then
            cp_warn "Upgrades are being installed in the background - apt calls in this step wait for them (up to 10 min)."
        fi
    fi
    case "$id" in
        readme)    step_readme ;;
        forensics) step_forensics ;;
        review)    step_review ;;
        critical)  step_critical ;;
        upgrades)  step_upgrades ;;
        manual)    step_manual_list manual "LATE MANUAL" "LATE MANUAL items done?" ;;
        todo)      step_todo ;;
        *)         # shellcheck disable=SC2086
                   run_script "$id" ${SCMD[$id]} ;;
    esac
}

next_step() { local s; for s in "${STEPS[@]}"; do step_done "$s" || { echo "$s"; return; }; done; }

# -------------------------------------------------------------------- menu --
step_info() {   # extra text after a step in the menu
    local id="$1" rc s f
    if step_done "$id"; then
        rc="$(step_rc "$id")"
        case "$rc" in
            0|m) echo "$(fmt_dur "$(step_dur "$id")")" ;;
            bg)  echo "$(job_text upgrade)" ;;
            *)   echo "$(fmt_dur "$(step_dur "$id")")  ${CP_C_YEL}exit $rc${CP_C_OFF} (see log)" ;;
        esac
        return
    fi
    f="${SCMD[$id]%% *}"
    if [ -n "$f" ] && [ ! -f "$HERE/$f" ] && [ "$id" != readme ] && [ "$id" != critical ]; then echo "${CP_C_YEL}($f missing)${CP_C_OFF}"; return; fi
    case "$id" in
        review)   [ "$(job_state baseline)" = running ] && echo "(waits for the scan)" ;;
        critical) s="$(cp_cfg_get SERVICES)"; echo "${s:+[$s]}" ;;
        upgrades) [ "$(job_state apt)" = "done" ] && echo "($(debs_count) files downloaded)" ;;
        todo)     echo "($(todo_count) open)" ;;
    esac
}

draw_menu() {
    local now t0 i id mark nx score a u sv jobs="" j t
    now="$(date +%s)"; t0="$(cat "$ST/t0" 2>/dev/null || echo "$now")"
    score="$(cp_screenshot_prompt --score 2>/dev/null)"
    echo
    echo "${CP_C_CYN}======== CP19 start.sh ========${CP_C_OFF}  $(fmt_dur $(( now - t0 ))) since start | auto mode $(auto_on && echo ON || echo off)${score:+ | score: $score}"
    if cp_cfg_has ADMINS; then
        a="$(cp_cfg_get ADMINS)"; u="$(cp_cfg_get USERS)"; sv="$(cp_cfg_get SERVICES)"
        echo "  README: admins ${a:--} | users ${u:--} | critical services ${sv:-?}"
    else
        echo "  README: ${CP_C_YEL}not entered yet${CP_C_OFF} (step 1)"
    fi
    for j in apt baseline upgrade; do
        t="$(job_text "$j")"; [ -n "$t" ] && jobs+="${jobs:+ | }$t"
    done
    echo "  Background: $jobs"
    i=0
    for id in "${STEPS[@]}"; do
        i=$((i + 1))
        if step_done "$id"; then
            case "$(step_rc "$id")" in 0|m|bg) mark="${CP_C_GRN}[x]${CP_C_OFF}" ;; *) mark="${CP_C_YEL}[!]${CP_C_OFF}" ;; esac
        else mark="[ ]"; fi
        printf '  %2d %s %-31s %s\n' "$i" "$mark" "${SNAME[$id]}" "$(step_info "$id")"
    done
    nx="$(next_step)"
    if [ -n "$nx" ]; then
        for i in "${!STEPS[@]}"; do [ "${STEPS[$i]}" = "$nx" ] && break; done
        printf '  Enter = %d %s' $((i + 1)) "${SNAME[$nx]}"
    else
        printf '  All steps done'
    fi
    printf ' | 1-%d = that step | t = TODO (%s) | a = auto on/off | q = quit' "${#STEPS[@]}" "$(todo_count)"
    for j in apt baseline; do case "$(job_state "$j")" in failed|died) printf ' | j = restart failed background jobs'; break ;; esac; done
    echo
}

restart_failed_jobs() {
    local j
    for j in apt baseline; do
        case "$(job_state "$j")" in failed|died) cp_info "Restarting $j job"; job_spawn "$j" ;; esac
    done
}

# -------------------------------------------------------------------- main --
case "${1:-}" in
    --status) draw_menu; exit 0 ;;
    --reset)
        for j in apt baseline upgrade; do
            [ "$(job_state "$j")" = running ] && { cp_err "$j job still running - wait for it or stop it first"; exit 1; }
        done
        cp_ask "Forget step ticks and background-job state (README answers, TODO list and logs are kept)?" n || exit 0
        rm -rf "$ST"; cp_ok "start.sh state cleared."; exit 0 ;;
    -h|--help) awk 'NR > 1 && /^#/ { sub(/^# ?/, ""); print; next } NR > 1 { exit }' "$0"; exit 0 ;;
    "") ;;
    *) echo "Unknown option $1 (see: bash start.sh --help)"; exit 1 ;;
esac

exec 9> "$ST/lock"
if ! flock -n 9; then echo "start.sh is already running in another terminal - use that one."; exit 1; fi
[ -f "$ST/t0" ] || date +%s > "$ST/t0"
[ -f "$ST/auto" ] || echo 1 > "$ST/auto"
# README answers saved earlier (readme.sh run by hand) -> step 1 is already done
if readme_ok && [ ! -f "$ST/step.readme" ]; then step_set readme m 0; fi
# an older start.sh logged the README step with `script` (pasted passwords in the transcript) - drop it
grep -qs "Script started" "$LOGS/readme.log" && rm -f "$LOGS/readme.log"

start_jobs
cp_ok "Background: $(job_text apt) | $(job_text baseline)"
if ! readme_ok; then
    run_step readme
fi

while true; do
    draw_menu
    if ! read -r -p "> " choice; then echo; break; fi
    choice="${choice//[[:space:]]/}"
    case "$choice" in
        "")  nx="$(next_step)"
             if [ -n "$nx" ]; then run_step "$nx"; else cp_info "All steps are done - t = TODO list, a number re-runs a step."; fi ;;
        [0-9]|[0-9][0-9])
             if [ "$choice" -ge 1 ] && [ "$choice" -le "${#STEPS[@]}" ]; then run_step "${STEPS[$((choice - 1))]}"
             else cp_warn "No step $choice"; fi ;;
        a|A) if auto_on; then echo 0 > "$ST/auto"; cp_info "Auto mode off - scripts ask every question."
             else echo 1 > "$ST/auto"; cp_info "Auto mode on - always-right steps are not asked."; fi ;;
        t|T) show_todo ;;
        j|J) restart_failed_jobs ;;
        q|Q) break ;;
        *)   cp_warn "Unknown choice '$choice'" ;;
    esac
done
echo
cp_info "Quit. Background: $(job_text apt) | $(job_text baseline)$( [ "$(job_state upgrade)" != none ] && echo " | $(job_text upgrade)")"
cp_info "Background jobs keep running. Run 'sudo bash start.sh' again to continue where you left off."
